#python api_test.py --dataset devign --features wo_ggnn;
#for l in 0 5 2 4 3; do
#  python api_test.py --dataset devign --features ggnn --num_layers $l;
#done

python api_test.py --dataset devign --features ggnn