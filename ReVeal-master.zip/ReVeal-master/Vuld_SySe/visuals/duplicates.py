if __name__ == '__main__':
    # ../ data / VulDeePecker / CWE - 119 - processed.json        62.7860
    # ../ data / VulDeePecker / CWE - 399 - processed.json        74.8126
    # ../ data / SySeVR / API_function_call - processed.json      44.6083
    # ../ data / SySeVR / Arithmetic_expression - processed.json  57.4880
    # ../ data / SySeVR / Array_usage - processed.json            43.5030
    # ../ data / SySeVR / Pointer_usage - processed.json          54.5757
    datasets = ['Juliet', 'Vul 119', 'Vul 399', 'S API', 'S expr', 'S Array', 'S Pointer', 'Draper', ]
    duplicates = []