u_char * foo(u_char *data)
{ 
  if(foo1)
    bar1();
  else if(foo2)
    bar2();
  else if(foo3)
    bar3();
}


