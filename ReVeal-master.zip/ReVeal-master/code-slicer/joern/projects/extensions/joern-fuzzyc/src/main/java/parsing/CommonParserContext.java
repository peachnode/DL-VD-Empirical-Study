package parsing;

public class CommonParserContext
{
	public String filename;
	public TokenSubStream stream;
}
