package ast.logical.statements;

public class JumpStatement extends Statement
{

}
