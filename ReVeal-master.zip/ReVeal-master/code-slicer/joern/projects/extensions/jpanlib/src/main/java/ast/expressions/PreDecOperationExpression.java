package ast.expressions;

public class PreDecOperationExpression extends PreIncDecOperationExpression
{
}
