package inputModules.csv.KeyedCSV.exceptions;

public class InvalidCSVFile extends Exception
{

	private static final long serialVersionUID = -7279016694374921095L;

	public InvalidCSVFile(String message) {
		super(message);
	}
}
