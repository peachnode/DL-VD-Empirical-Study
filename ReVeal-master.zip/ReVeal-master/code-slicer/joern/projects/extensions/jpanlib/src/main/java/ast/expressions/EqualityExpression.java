package ast.expressions;

public class EqualityExpression extends BinaryOperationExpression
{
}
