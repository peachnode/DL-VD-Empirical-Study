package ast.logical.statements;

import ast.ASTNode;

public class Statement extends ASTNode
{

}
