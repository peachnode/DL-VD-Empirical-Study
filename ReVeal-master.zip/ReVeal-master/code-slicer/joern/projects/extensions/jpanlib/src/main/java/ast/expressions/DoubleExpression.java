package ast.expressions;

public class DoubleExpression extends PrimaryExpression
{
}
