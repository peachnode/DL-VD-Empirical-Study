package inputModules.csv.csv2ast;

import ast.ASTNode;
import inputModules.csv.KeyedCSV.KeyedCSVRow;

public class CSVASTNodeFactory
{

	public ASTNode createNode(KeyedCSVRow keyedRow)
	{
		return null;
	}

}
