package databaseNodes;

public class EdgeKeys {

	// symbol for reaching definitions (EdgeTypes.REACHES)
	public static final String VAR = "var";
}
