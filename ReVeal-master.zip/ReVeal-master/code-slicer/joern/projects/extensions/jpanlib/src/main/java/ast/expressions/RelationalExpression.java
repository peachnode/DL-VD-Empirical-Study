package ast.expressions;

public class RelationalExpression extends BinaryOperationExpression
{
}
