package ast.expressions;

import ast.statements.ExpressionHolder;

// Pseudo node
public class Callee extends ExpressionHolder
{
}
