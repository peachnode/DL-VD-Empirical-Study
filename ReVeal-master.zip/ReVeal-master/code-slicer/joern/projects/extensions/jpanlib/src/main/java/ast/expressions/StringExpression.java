package ast.expressions;

public class StringExpression extends PrimaryExpression
{
}
