package ast.expressions;

public class PostIncOperationExpression extends PostIncDecOperationExpression
{
}
