package ast.expressions;

public class CastTarget extends Expression
{
}
