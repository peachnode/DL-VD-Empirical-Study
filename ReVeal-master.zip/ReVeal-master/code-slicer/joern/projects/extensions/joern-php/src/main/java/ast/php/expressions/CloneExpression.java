package ast.php.expressions;

import ast.expressions.UnaryExpression;

public class CloneExpression extends UnaryExpression
{
}
