package ast.php.expressions;

import ast.expressions.UnaryExpression;

public class PrintExpression extends UnaryExpression
{
}
